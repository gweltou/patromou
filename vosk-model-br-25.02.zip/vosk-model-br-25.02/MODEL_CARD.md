# Vosk Breton Model 25.02

A Vosk STT model for the breton language.
Trained with Kaldi.

5.5M parameters acoustic model
13 TDNN hidden layers of width 786
Learning rate: 1e-3 -> 1e-4
Trained over 30 epochs

## Evaluation

Test "Bali Breizh er Poc'hêr : Karaez 1" : **WER 32.8%, CER 17.52%** \
Test "France3, Ensklask sosiologel el lise" : **WER 17.84%, CER 8.25%** \
Test Mozilla Common Voice 19 : **WER 31.99%, CER 16.88%%** \

## Remarks

Transcription errors are common and need to be corrected by the user.
This model performs best on read speech, audiobook, podcast, news reporting, radio shows.
It performs poorly on Gwenedeg breton, songs, old recordings.
Training recipe uses white noise perturbation to increase the model's robustness. 

## Training data

- Total audio length:	64h 47' 58''
- 42 275 utterances
- Lexicon: **61,478 words** \
- Text corpus: **2,743,300 words**

### Data sources

* Youtube videos from Brezhoweb channel, up to September 2024
* Youtube videos from #Brezhoneg magazine, volume 11 to volume 44
* OPAB, Desketa recordings
* Mozilla Common Voice V19, train split
Becedia/Denis Le Bozec - Langonnet Becedia
Becedia/komzoù-brezhoneg_catherine-quiniou-tine-plounevez-du-faou
Becedia/komzoù-brezhoneg_suzanne_goarnisson_scrignac
Bro_Vear/ar_bouch_alen_toudig
Bro_Vear/ar_gaerell_michel_talgen
Bro_Vear/jermen_omnes_ar_chog
Bro_Vear/jermen_omnes_ar_voualch
Bro_Vear/pilulennou_da_yaouankaat_ifig_raoul
Dastum/524Y00030-11_kontadenn_an_otomobil
Dastum/59533_anjela_duval
Dastum/61165_kontadenn_an_touseg
Dastum/61334_petra_vo_kazetenn_ar_vro_plin
Dastum/a73552_Intañv_al_lochenn
Dizale/Ar_Vreudeur_Bloom
Dizale/Birmania/Birmania_Mouezh
Dizale/Kabellig_Ruz/Kabellig_Ruz
Dizale/Lampedusa/Lampedusa_Beach_22122016
Dizale/Mandela/Mandela_Bob_Nolwenn
Dizale/Oceanopolis/Oceanopolis
Dizale/Wangari_Maathai/Wangari_Maathai_Bob_Nolwenn
FR3/Flux_chantier_dun_futur_tiers_lieu_à_Quimper_bzg_-_YouTube
FR3/anna_loeiza_pemzek_teiz
FR3/fr3_Hêrezh_ar_Seiz_Breur
Kaouenn/an_tad_michel_jaouen_3109ac50477be39dc2cf27e4994d4237
Kaouenn/arouez_an_evned_b9e9b12755d8349e76fb1a1f56759b56
Kaouenn/filip_neri_dc978d84b913c8d87c80b4da19a3c30b
Kaouenn/noz_an_nedeleg_yf_kemener_6398ee99ad216a2992af353f9313c68a
Kaouenn/noz_kalana_997e41c2016afe4338977389ba65c6a9
Kaouenn/trugarez_tad_trugarez_mamm
Mélanie_Jouitteau/AM_Louboutin_Ia
Mélanie_Jouitteau/Huguette_Gaudart
Mélanie_Jouitteau/Huguette_Gaudart_06_2023
Mélanie_Jouitteau/Janig_I_II
Mélanie_Jouitteau/ya_sonerezh_ekologel
RKB/211026-Atersadenn-war-eeun-Jeannot-Flaguel
RKB/PLANT-s11-ISABELLE-CAIGNARD-SKAMPIOLA
RKB/al_linad_gant_isabelle_39469393-1dab-4793-9722-ab85655a812b
RKB/an-drez-gant-isabelle_5986dfc0-05dd-4ec8-987a-abfdbedce954
RKB/an_ach_gant_bronwenn_f2998c94-33bf-4b56-a782-f0c78fe15625
RKB/an_turch_gant_isabelle-4b072efb-5324-4014-9827-9e82115f36c3
RKB/ar-begar-gant-mailys_9d0c7c9a-fb53-4d36-92d1-307e622fa863
RKB/ar-chokombrez-gant-marilia_a53561cf-707b-41c9-9176-80da8240f313
RKB/ar-melezour-pierre-ollivier_b6c6bbad-6a36-4f0a-a00d-1e0d15f779d8
RKB/ar_balann_gweltaz_17ce07e2-5c70-4e4c-aba8-a51a895bf241
RKB/ar_boked_roz_gant_michel_de23dc61-aa69-4710-9791-95c0489a98f7
RKB/ar_brug_gant_jean-daniel_5ad37932-7795-4cf9-9add-6174b9973c65
RKB/ar_gwez_avalou_gant_dominique_709a2782-0a0a-400d-af7d-19b17841fc43
RKB/ar_gwez_avaloù_gant_Nelly_03c92a83-5903-4449-9cd4-1722e66de6aa
RKB/ar_penn-ognon_gant_isabelle_caignard_f3c24c8d-4d6a-484d-85be-6f4787305c2d
RKB/ar_skav_gant_tiphaine_ha_nicolas_a485162e-d179-43dc-9c4f-c11c9b448fc8
RKB/ar_spern_gwenn_gant_laurent_cf68d8d1-a454-428b-9336-bcfe21271192
RKB/ar_stagerez_gant_isabelle_e1702144-7512-4d02-b72f-4dd91a6cc9c7
RKB/boked_bleunv_dc7a6efd-50e5-4ce3-bd1c-49b328619b59
RKB/bougainvilliers_62b8e3b3-b791-4e19-9e09-9ee402944cf6
RKB/jermen_boutier_buhez_bb9f7112-e62f-4cb9-ae7a-ef6a7b3a9767
RKB/person-an-drinded_734f8106-0766-4932-b9c7-2ee942ef055e
RKB/rkb_fulup-ar-skanv-jermen-boutier_a4fca73b-f55e-4d6e-802e-600bcc7b99f1
RKB/stlanvesk_gant_tim_c05d79ad-4622-4d55-bbe9-10e24f2f6d94
Radio Kerne/Rodeier-2024-06-17-Dek-Mil-Komz-E-Diksioner-Kreiz-Breizh
YBD/rann1
Ya!/872/872-p_2-Bro-Chili-Yaganed
Ya!/872/872-p_2-Bro-India-Manifestadegoù
Ya!/900/900-p_3-Ger-ar-pennskridaozer-nevez
Ya!/900/900-p_3-pignat-tour-tan-Eckmülh
Ya!/900/900-p_4-An-takad-tenn
Ya!/900/900-p_5-Al-liorzh-marzhus
Ya!/900/900-p_5-Berr-ha-berr
Ya!/900/900-p_5-Izel-live-an-dour-er-mirlechiou
youtube/Adeux__2023__bzg_glez_biskrivet_-_Deskiñ_ar_chemmadurioù
youtube/Channig_an_Normand_-_Jeanne_Le_Normand_-_YouTube
youtube/Denez Abernot - Gwerz ar vezhinerien
youtube/Durand-Le_Ludec__2022__Chess_Back-hold_er_GBB_2023
youtube/Kinnig_an_displeger_verbou_brezhoneg
youtube/PlouzFoen - Dieubstil 2 NANANI
youtube/PlouzFoen_Dieubstil_STRAKAL
youtube/neus_ket_deus_archoazh
